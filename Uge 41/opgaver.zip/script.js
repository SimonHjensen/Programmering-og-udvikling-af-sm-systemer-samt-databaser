// Task 5
//document.getElementById('').addEventListener('', () => {
    setTimeout(() => {
        // Write code here
    }, 1000);
//});

// Debouncer - you can use this with any function
// Read more: https://www.geeksforgeeks.org/debouncing-in-javascript/
const debouncer = (func, delay) => {
    let debounceTimer;

    return function() {
        const context = this;
        const args = arguments;

        clearTimeout(debounceTimer);

        debounceTimer = setTimeout(() => func.apply(context, args), delay);
    };
}

// Task 8
document.getElementById('task8Button').addEventListener('click', debouncer(() => {
    // Write code here
}, 1000));

// Task 10
document.getElementById('task10Form').addEventListener('submit', (e) => {
    e.preventDefault();

    // Write code here
});

// Task 12
// fetch('')