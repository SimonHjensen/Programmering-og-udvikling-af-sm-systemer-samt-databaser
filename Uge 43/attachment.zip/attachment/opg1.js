/**
 * Task 1:
 * Write a program that captures command line arguments when you run it.
 * The program should console.log() the first argument passed an an error if it is not passed.
 * 
 * To run this program, you need to open a terminal in this folder and write "node opg1.js"
 * If you do not know what a command line argument is, it is when you add something after the filename.
 * For example: "node opg1.js firstArgument secondArgument"
 * 
 * Help: Slide 12
 */

// This is how you get the arguments
let args = process.argv;

/**
 * I am logging the arguments, and you can actually see that the first two are node and the file
 * You need to use the third one
 */
console.log(args);